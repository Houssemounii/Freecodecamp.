# Issue Tracker

[![status-badge](https://ci.radii.page/api/badges/127/status.svg)](https://ci.radii.page/api/badges/127/status.svg)

This is the boilerplate for the Issue Tracker project. Instructions for building your project can be found at https://www.freecodecamp.org/learn/quality-assurance/quality-assurance-projects/issue-tracker
